# Redeem
I have developed a plugin that allows players with PlayerpointsAPI support to redeem a "gift code". If you want to make a coin/point style sale from the site, it will allow this.
